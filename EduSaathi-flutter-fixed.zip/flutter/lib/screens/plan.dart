import 'package:flutter/material.dart';
import '../store.dart';

class PlanScreen extends StatefulWidget {
  const PlanScreen({super.key});
  @override
  State<PlanScreen> createState() => _PlanScreenState();
}

class _PlanScreenState extends State<PlanScreen> {
  List<Map<String, dynamic>> subs = Store.list('att');
  final name = TextEditingController();
  static const target = 0.75;

  // Classes you can still miss while staying at or above the target: floor(att/target - total)
  int _canMiss(Map<String, dynamic> s) {
    final v = ((s['att'] as int) / target - (s['tot'] as int)).floor();
    return v < 0 ? 0 : v;
  }

  void _bump(Map<String, dynamic> s, bool present) {
    setState(() { s['tot'] = (s['tot'] as int) + 1; if (present) s['att'] = (s['att'] as int) + 1; });
    Store.set('att', subs);
  }

  @override
  void dispose() { name.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Attendance (75% target)', style: Theme.of(context).textTheme.titleSmall),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: TextField(controller: name, decoration: const InputDecoration(hintText: 'Subject', border: OutlineInputBorder()))),
        const SizedBox(width: 8),
        FilledButton(onPressed: () {
          if (name.text.trim().isEmpty) return;
          setState(() => subs.add({'id': DateTime.now().millisecondsSinceEpoch, 'name': name.text.trim(), 'att': 0, 'tot': 0}));
          name.clear(); Store.set('att', subs);
        }, child: const Text('Add')),
      ]),
      ...subs.map((s) {
        final tot = s['tot'] as int, att = s['att'] as int;
        final pct = tot == 0 ? 0 : (100 * att / tot).round();
        return Card(margin: const EdgeInsets.only(top: 12), child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Expanded(child: Text('${s['name']}  —  $pct%  ($att/$tot)', style: const TextStyle(fontWeight: FontWeight.w600))), IconButton(icon: const Icon(Icons.delete_outline), onPressed: () { setState(() => subs.remove(s)); Store.set('att', subs); })]),
          Text('You can miss ${_canMiss(s)} more class(es)'),
          const SizedBox(height: 8),
          Row(children: [FilledButton(onPressed: () => _bump(s, true), child: const Text('Present')), const SizedBox(width: 8), OutlinedButton(onPressed: () => _bump(s, false), child: const Text('Absent'))]),
        ])));
      }),
    ]);
  }
}
