import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../store.dart';

const _links = <List<String>>[
  ['NPTEL', 'https://nptel.ac.in'],
  ['SWAYAM', 'https://swayam.gov.in'],
  ['Khan Academy', 'https://www.khanacademy.org'],
  ['MIT OpenCourseWare', 'https://ocw.mit.edu'],
  ['Internshala', 'https://internshala.com'],
  ['The Forage', 'https://www.theforage.com'],
  ['National Scholarship Portal', 'https://scholarships.gov.in'],
  ['Tele-MANAS (mental health)', 'https://telemanas.mohfw.gov.in'],
];
const _moods = ['😄', '🙂', '😐', '😟', '😢'];

Future<void> _open(String u) => launchUrl(Uri.parse(u), mode: LaunchMode.externalApplication);

class ConnectScreen extends StatefulWidget {
  const ConnectScreen({super.key});
  @override
  State<ConnectScreen> createState() => _ConnectScreenState();
}

class _ConnectScreenState extends State<ConnectScreen> {
  final room = TextEditingController(text: 'study-room');
  List<Map<String, dynamic>> moods = Store.list('moods');

  @override
  void dispose() { room.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final tt = Theme.of(context).textTheme;
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Study room (Jitsi)', style: tt.titleSmall),
      const SizedBox(height: 8),
      TextField(controller: room, decoration: const InputDecoration(border: OutlineInputBorder())),
      const SizedBox(height: 8),
      Align(alignment: Alignment.centerLeft, child: FilledButton(onPressed: () => _open('https://meet.jit.si/${Uri.encodeComponent(room.text.trim().replaceAll(RegExp(r'\s+'), '-'))}'), child: const Text('Join room'))),
      const Divider(height: 32),
      Text('Mood check-in', style: tt.titleSmall),
      Row(children: _moods.map((m) => IconButton(iconSize: 32, onPressed: () {
            setState(() => moods.add({'d': DateTime.now().toIso8601String(), 'm': m}));
            Store.set('moods', moods);
          }, icon: Text(m, style: const TextStyle(fontSize: 28)))).toList()),
      Text('Recent: ${moods.reversed.take(7).toList().reversed.map((e) => e['m']).join(' ')}'),
      const Divider(height: 32),
      Text('Learning, careers & support', style: tt.titleSmall),
      ..._links.map((l) => ListTile(contentPadding: EdgeInsets.zero, title: Text(l[0]), trailing: const Icon(Icons.open_in_new, size: 18), onTap: () => _open(l[1]))),
    ]);
  }
}
