import 'dart:async';
import 'package:flutter/material.dart';
import '../ai.dart';
import '../store.dart';

class TodayScreen extends StatefulWidget {
  const TodayScreen({super.key});
  @override
  State<TodayScreen> createState() => _TodayScreenState();
}

class _TodayScreenState extends State<TodayScreen> {
  List<Map<String, dynamic>> tasks = Store.list('plan');
  final ctl = TextEditingController();
  String kind = 'Task';
  int secs = 1500;
  Timer? timer;
  String plan = '';
  bool busy = false;

  void _save() {
    Store.set('plan', tasks);
    if (plan.isNotEmpty) setState(() => plan = ''); // plan no longer matches tasks -> clear so it's regenerated
  }

  void _add() {
    final t = ctl.text.trim();
    if (t.isEmpty) return;
    setState(() => tasks.add({'id': DateTime.now().millisecondsSinceEpoch, 't': t, 'kind': kind, 'done': false}));
    ctl.clear();
    _save();
  }

  void _toggleTimer() {
    if (timer?.isActive ?? false) {
      timer!.cancel();
      setState(() {});
      return;
    }
    timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (secs <= 1) {
        t.cancel();
        setState(() => secs = 1500);
      } else {
        setState(() => secs--);
      }
    });
    setState(() {});
  }

  Future<void> _gen() async {
    final open = tasks.where((x) => x['done'] != true).toList();
    if (open.isEmpty) return setState(() => plan = 'Add tasks first.');
    setState(() => busy = true);
    try {
      plan = await aiCall(Sys.plan, '${open.map((x) => '${x['kind']}: ${x['t']}').join('\n')}\n\n${appContext()}');
    } catch (e) {
      plan = e.toString().replaceFirst('Exception: ', '');
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  void dispose() {
    timer?.cancel();
    ctl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final running = timer?.isActive ?? false;
    final tt = Theme.of(context).textTheme;
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('To-do & deadlines', style: tt.titleSmall),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: TextField(controller: ctl, decoration: const InputDecoration(hintText: 'Add a task, assignment or exam', border: OutlineInputBorder()), onSubmitted: (_) => _add())),
        const SizedBox(width: 8),
        DropdownButton<String>(value: kind, items: const ['Task', 'Assignment', 'Exam'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setState(() => kind = v!)),
        IconButton.filled(onPressed: _add, icon: const Icon(Icons.add)),
      ]),
      ...tasks.map((x) => CheckboxListTile(
            dense: true,
            controlAffinity: ListTileControlAffinity.leading,
            value: x['done'] == true,
            title: Text('${x['t']}', style: x['done'] == true ? const TextStyle(decoration: TextDecoration.lineThrough) : null),
            subtitle: Text('${x['kind']}'),
            secondary: IconButton(icon: const Icon(Icons.close), onPressed: () { setState(() => tasks.remove(x)); _save(); }),
            onChanged: (v) { setState(() => x['done'] = v); _save(); },
          )),
      const Divider(height: 32),
      Text('Focus', style: tt.titleSmall),
      Center(child: Text('${(secs ~/ 60).toString().padLeft(2, '0')}:${(secs % 60).toString().padLeft(2, '0')}', style: tt.displayLarge)),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        FilledButton(onPressed: _toggleTimer, child: Text(running ? 'Pause' : 'Start')),
        const SizedBox(width: 8),
        OutlinedButton(onPressed: () { timer?.cancel(); setState(() => secs = 1500); }, child: const Text('Reset')),
      ]),
      const Divider(height: 32),
      Text('Plan my day', style: tt.titleSmall),
      const SizedBox(height: 8),
      Align(alignment: Alignment.centerLeft, child: FilledButton(onPressed: busy ? null : _gen, child: Text(busy ? 'Planning…' : 'Generate plan'))),
      if (plan.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: SelectableText(plan)),
    ]);
  }
}
