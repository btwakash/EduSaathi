import 'package:flutter/material.dart';
import 'player.dart';
import '../ai.dart';
import '../store.dart';

class StudyScreen extends StatefulWidget {
  const StudyScreen({super.key});
  @override
  State<StudyScreen> createState() => _StudyScreenState();
}

class _StudyScreenState extends State<StudyScreen> {
  List<Map<String, dynamic>> lecs = Store.list('lectures');
  List<Map<String, dynamic>> chat = Store.list('chat');
  final title = TextEditingController(), url = TextEditingController(), q = TextEditingController();
  bool busy = false;

  Future<void> _ask() async {
    final m = q.text.trim();
    if (m.isEmpty || busy) return;
    q.clear();
    final hist = chat.reversed.take(8).toList().reversed
        .map((c) => {'role': c['r'] == 'u' ? 'user' : 'assistant', 'content': '${c['m']}'})
        .toList();
    setState(() { chat.add({'r': 'u', 'm': m}); busy = true; });
    Store.set('chat', chat);
    String a;
    try { a = await aiCall('${Sys.tutor}\n${appContext()}', m, history: hist); } catch (e) { a = e.toString().replaceFirst('Exception: ', ''); }
    if (!mounted) return;
    setState(() { chat.add({'r': 'a', 'm': a}); busy = false; });
    Store.set('chat', chat);
  }

  @override
  void dispose() { title.dispose(); url.dispose(); q.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final tt = Theme.of(context).textTheme;
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Lectures', style: tt.titleSmall),
      const SizedBox(height: 8),
      TextField(controller: title, decoration: const InputDecoration(labelText: 'Lecture name', border: OutlineInputBorder())),
      const SizedBox(height: 8),
      TextField(controller: url, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'YouTube link', border: OutlineInputBorder())),
      const SizedBox(height: 8),
      Align(alignment: Alignment.centerLeft, child: FilledButton(onPressed: () {
        if (title.text.trim().isEmpty || url.text.trim().isEmpty) return;
        setState(() => lecs.add({'id': DateTime.now().millisecondsSinceEpoch, 'title': title.text.trim(), 'url': url.text.trim(), 'pct': 0}));
        title.clear(); url.clear(); Store.set('lectures', lecs);
      }, child: const Text('Add'))),
      ...lecs.map((l) => ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.play_circle_outline),
            title: Text('${l['title']}'),
            subtitle: LinearProgressIndicator(value: (l['pct'] as num) / 100),
            onTap: () async {
              await Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerScreen(lecture: l, onChanged: () => Store.set('lectures', lecs))));
              if (mounted) setState(() {}); // refresh progress after returning
            },
            trailing: PopupMenuButton<String>(
              onSelected: (v) {
                setState(() { if (v == 'p') { l['pct'] = ((l['pct'] as num) + 25).clamp(0, 100); } else { lecs.remove(l); } });
                Store.set('lectures', lecs);
              },
              itemBuilder: (_) => [PopupMenuItem(value: 'p', child: Text('${l['pct']}% · +25%')), const PopupMenuItem(value: 'd', child: Text('Delete'))],
            ),
          )),
      const Divider(height: 32),
      Text('AI chat', style: tt.titleSmall),
      const SizedBox(height: 8),
      ...chat.map((c) => Align(
            alignment: c['r'] == 'u' ? Alignment.centerRight : Alignment.centerLeft,
            child: Container(
              margin: const EdgeInsets.symmetric(vertical: 4),
              padding: const EdgeInsets.all(10),
              constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8),
              decoration: BoxDecoration(color: c['r'] == 'u' ? Theme.of(context).colorScheme.primaryContainer : Theme.of(context).colorScheme.surfaceContainerHighest, borderRadius: BorderRadius.circular(12)),
              child: SelectableText('${c['m']}'),
            ),
          )),
      Row(children: [
        Expanded(child: TextField(controller: q, decoration: const InputDecoration(hintText: 'Ask a doubt…', border: OutlineInputBorder()), onSubmitted: (_) => _ask())),
        IconButton.filled(onPressed: busy ? null : _ask, icon: busy ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.send)),
      ]),
    ]);
  }
}
