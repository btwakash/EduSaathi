import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import '../ai.dart';
import '../transcript.dart';

class PlayerScreen extends StatefulWidget {
  final Map<String, dynamic> lecture;
  final VoidCallback onChanged; // persist lecture changes
  const PlayerScreen({super.key, required this.lecture, required this.onChanged});
  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  late final String? _id = YoutubePlayer.convertUrlToId(widget.lecture['url'] as String);
  late final YoutubePlayerController _c = YoutubePlayerController(
    initialVideoId: _id ?? '',
    flags: const YoutubePlayerFlags(autoPlay: false, enableCaption: false, showLiveFullscreenButton: false, forceHD: false),
  )..addListener(_onTick);
  bool busy = false;
  String status = '';
  int _lastSaved = -1;

  void _onTick() {
    final dur = _c.metadata.duration.inSeconds;
    if (dur <= 0 || !_c.value.isPlaying) return;
    final pct = (100 * _c.value.position.inSeconds / dur).round().clamp(0, 100);
    // Keep stored progress in sync with what was actually watched (never goes backwards).
    if (pct > (widget.lecture['pct'] as num) && pct != _lastSaved && pct % 5 == 0) {
      _lastSaved = pct;
      widget.lecture['pct'] = pct;
      widget.onChanged();
    }
  }

  Future<void> _summarise() async {
    if (_id == null || busy) return;
    setState(() { busy = true; status = 'Fetching transcript…'; });
    try {
      final t = await fetchTranscript(_id!);
      final s = await summarizeLong(t, onProgress: (m) { if (mounted) setState(() => status = m); });
      widget.lecture['sum'] = s;
      widget.onChanged();
      if (mounted) setState(() => status = '');
    } catch (e) {
      if (mounted) setState(() => status = e.toString().replaceFirst('Exception: ', ''));
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  void deactivate() { _c.pause(); super.deactivate(); }

  @override
  void dispose() {
    _c.removeListener(_onTick);
    _c.dispose();
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_id == null) return Scaffold(appBar: AppBar(), body: const Center(child: Text('Invalid YouTube link')));
    final sum = widget.lecture['sum'] as String?;
    return YoutubePlayerBuilder(
      // FIX: exit-fullscreen must explicitly restore portrait + system bars.
      onEnterFullScreen: () => SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]),
      onExitFullScreen: () {
        SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
        SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
        Future.delayed(const Duration(seconds: 1), () => SystemChrome.setPreferredOrientations(DeviceOrientation.values));
      },
      player: YoutubePlayer(
        controller: _c,
        showVideoProgressIndicator: true,
        topActions: const [], // FIX: no title / settings / extra buttons
        bottomActions: [
          CurrentPosition(controller: _c),
          ProgressBar(controller: _c, isExpanded: true),
          RemainingDuration(controller: _c),
          FullScreenButton(controller: _c),
        ],
      ),
      builder: (context, player) => PopScope(
        canPop: !_c.value.isFullScreen,
        onPopInvoked: (didPop) { if (!didPop) _c.toggleFullScreenMode(); },
        child: Scaffold(
          appBar: AppBar(title: Text('${widget.lecture['title']}')),
          body: ListView(children: [
            player,
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                FilledButton.icon(
                  onPressed: busy ? null : _summarise,
                  icon: const Icon(Icons.auto_awesome),
                  label: Text(sum == null ? 'Summarise with AI' : 'Re-summarise'),
                ),
                if (status.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Row(children: [
                  if (busy) const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2)),
                  if (busy) const SizedBox(width: 8),
                  Expanded(child: Text(status)),
                ])),
                if (sum != null) Padding(padding: const EdgeInsets.only(top: 12), child: SelectableText(sum)),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}
