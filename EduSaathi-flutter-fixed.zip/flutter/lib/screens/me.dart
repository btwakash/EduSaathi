import 'package:flutter/material.dart';
import '../ai.dart';
import '../main.dart' show themeMode;
import '../store.dart';

class MeScreen extends StatefulWidget {
  const MeScreen({super.key});
  @override
  State<MeScreen> createState() => _MeScreenState();
}

class _MeScreenState extends State<MeScreen> {
  late final Map<String, dynamic> ai = Store.map('ai');
  late final url = TextEditingController(text: ai['url'] ?? '');
  late final model = TextEditingController(text: ai['model'] ?? '');
  late final key = TextEditingController(text: ai['key'] ?? '');

  void _saveAi() => Store.set('ai', {'url': url.text.trim(), 'model': model.text.trim(), 'key': key.text.trim()});

  @override
  void dispose() { url.dispose(); model.dispose(); key.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final tt = Theme.of(context).textTheme;
    final cur = Store.str('theme', 'system');
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Appearance', style: tt.titleSmall),
      const SizedBox(height: 8),
      SegmentedButton<String>(
        segments: const [ButtonSegment(value: 'system', label: Text('System')), ButtonSegment(value: 'light', label: Text('Light')), ButtonSegment(value: 'dark', label: Text('Dark'))],
        selected: {cur},
        onSelectionChanged: (s) {
          Store.set('theme', s.first);
          themeMode.value = switch (s.first) { 'light' => ThemeMode.light, 'dark' => ThemeMode.dark, _ => ThemeMode.system };
          setState(() {});
        },
      ),
      const Divider(height: 32),
      Text('AI engine (OpenAI-compatible)', style: tt.titleSmall),
      const SizedBox(height: 8),
      TextField(controller: url, onChanged: (_) => _saveAi(), decoration: const InputDecoration(hintText: defaultUrl, border: OutlineInputBorder())),
      const SizedBox(height: 8),
      TextField(controller: model, onChanged: (_) => _saveAi(), decoration: const InputDecoration(hintText: defaultModel, border: OutlineInputBorder())),
      const SizedBox(height: 8),
      TextField(controller: key, obscureText: true, onChanged: (_) => _saveAi(), decoration: const InputDecoration(hintText: 'API key', border: OutlineInputBorder())),
      const Divider(height: 32),
      Text('About', style: tt.titleSmall),
      const SizedBox(height: 8),
      const Text('EduSaathi — your calm study companion. Built by Akash Kumar Yadav.'),
    ]);
  }
}
