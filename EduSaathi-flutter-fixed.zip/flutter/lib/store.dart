import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

/// Local storage. Same "uc_" key prefix + JSON format as the original Capacitor app.
class Store {
  static late SharedPreferences _p;
  static Future<void> init() async => _p = await SharedPreferences.getInstance();

  static dynamic _raw(String k) {
    final s = _p.getString('uc_$k');
    if (s == null) return null;
    try {
      return jsonDecode(s);
    } catch (_) {
      return null;
    }
  }

  static List<Map<String, dynamic>> list(String k) {
    final v = _raw(k);
    return v is List ? v.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList() : [];
  }

  static Map<String, dynamic> map(String k) {
    final v = _raw(k);
    return v is Map ? Map<String, dynamic>.from(v) : {};
  }

  static String str(String k, String d) {
    final v = _raw(k);
    return v is String ? v : d;
  }

  static Future<void> set(String k, Object v) => _p.setString('uc_$k', jsonEncode(v));
}
