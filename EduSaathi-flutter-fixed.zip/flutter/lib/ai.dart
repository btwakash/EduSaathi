import 'dart:convert';
import 'dart:math';
import 'package:http/http.dart' as http;
import 'store.dart';

// SECURITY: no API key is bundled. Build with --dart-define=AI_PROXY_URL=https://your-proxy
// or let users enter their own OpenAI-compatible URL/key in Me -> AI engine.
const _proxy = String.fromEnvironment('AI_PROXY_URL');
const defaultUrl = 'https://api.groq.com/openai/v1';
const defaultModel = 'openai/gpt-oss-120b';

class Sys {
  static const tutor =
      'You are a patient tutor for college students. Be clear and concise. '
      'You can see the student\'s current app data below; use it when relevant (e.g. what they are watching, pending tasks, attendance) and never contradict it.';
  static const help =
      'You are a university helpdesk agent for Indian college students. Reply in 1-4 short sentences with the exact next step. Never invent fees, dates or policies.';
  static const plan =
      'You are a day planner for a college student. Use only the tasks given. Output ordered time blocks, 25-minute focus blocks with short breaks, exams and nearest deadlines first. One line per block, at most 15 lines, no intro or outro.';
  static const chunk =
      'Summarise this part of a lecture transcript into concise bullet-point notes. Keep key concepts, definitions, formulas and examples. No intro or outro.';
  static const finalSum =
      'You are given notes from consecutive parts of one lecture. Write a clear study summary: a 2-line overview, then "Key points" (bullets), then "Important terms/formulas" if any. Be concise.';
}

/// Snapshot of the student's live app data so the AI always matches what the UI shows.
String appContext({String? currentLecture}) {
  final tasks = Store.list('plan');
  final lecs = Store.list('lectures');
  final att = Store.list('att');
  final b = StringBuffer('--- Student app data (live) ---\n');
  if (currentLecture != null) b.writeln('Currently watching: $currentLecture');
  b.writeln('Lectures: ${lecs.isEmpty ? 'none' : lecs.map((l) => '${l['title']} (${l['pct']}% watched)').join('; ')}');
  b.writeln('Pending tasks: ${tasks.where((t) => t['done'] != true).map((t) => '${t['kind']}: ${t['t']}').join('; ').ifEmpty('none')}');
  b.writeln('Completed tasks: ${tasks.where((t) => t['done'] == true).map((t) => '${t['t']}').join('; ').ifEmpty('none')}');
  b.writeln('Attendance: ${att.map((s) => '${s['name']} ${s['att']}/${s['tot']}').join('; ').ifEmpty('none')}');
  return b.toString();
}

extension on String {
  String ifEmpty(String d) => isEmpty ? d : this;
}

Future<String> aiCall(String system, String user, {List<Map<String, String>> history = const []}) async {
  final cfg = Store.map('ai');
  final key = (cfg['key'] ?? '') as String;
  if (_proxy.isEmpty && key.isEmpty) throw Exception('Add your AI key in Me → AI engine.');
  final base = (_proxy.isNotEmpty ? _proxy : ((cfg['url'] ?? '') as String).isNotEmpty ? cfg['url'] : defaultUrl) as String;
  final model = ((cfg['model'] ?? '') as String).isNotEmpty ? cfg['model'] as String : defaultModel;
  final body = jsonEncode({
    'model': model,
    'temperature': 0.3,
    'messages': [
      {'role': 'system', 'content': system},
      ...history,
      {'role': 'user', 'content': user},
    ],
  });
  // Retry on rate limits / transient server errors (common when summarising many chunks).
  for (var attempt = 0;; attempt++) {
    final r = await http
        .post(
          Uri.parse('${base.replaceAll(RegExp(r'/$'), '')}/chat/completions'),
          headers: {'Content-Type': 'application/json', if (_proxy.isEmpty && key.isNotEmpty) 'Authorization': 'Bearer $key'},
          body: body,
        )
        .timeout(const Duration(seconds: 90));
    if (r.statusCode == 200) {
      return (jsonDecode(utf8.decode(r.bodyBytes))['choices'][0]['message']['content'] ?? '') as String;
    }
    final retryable = r.statusCode == 429 || r.statusCode >= 500;
    if (!retryable || attempt >= 3) throw Exception('AI error ${r.statusCode}');
    await Future.delayed(Duration(seconds: 2 << attempt));
  }
}

List<String> _split(String t, int size) {
  final out = <String>[];
  var i = 0;
  while (i < t.length) {
    var end = min(i + size, t.length);
    if (end < t.length) {
      final sp = t.lastIndexOf(' ', end);
      if (sp > i + size ~/ 2) end = sp;
    }
    out.add(t.substring(i, end));
    i = end;
  }
  return out;
}

/// Map-reduce summary so videos of any length fit the model's context window.
Future<String> summarizeLong(String transcript, {void Function(String)? onProgress}) async {
  const size = 9000;
  var parts = _split(transcript, size);
  for (var round = 0; parts.length > 1 || round == 0; round++) {
    final notes = <String>[];
    for (var i = 0; i < parts.length; i++) {
      onProgress?.call('Summarising part ${i + 1} of ${parts.length}…');
      notes.add(await aiCall(Sys.chunk, parts[i]));
    }
    final merged = notes.join('\n\n');
    if (merged.length <= size || round >= 4) {
      onProgress?.call('Writing final summary…');
      return aiCall(Sys.finalSum, merged);
    }
    parts = _split(merged, size);
  }
  return '';
}
