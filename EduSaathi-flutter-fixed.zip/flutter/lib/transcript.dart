import 'package:youtube_explode_dart/youtube_explode_dart.dart';

/// Downloads the caption track (English preferred, else first available) as plain text.
Future<String> fetchTranscript(String videoId) async {
  final yt = YoutubeExplode();
  try {
    final manifest = await yt.videos.closedCaptions.getManifest(videoId);
    if (manifest.tracks.isEmpty) {
      throw Exception('This video has no captions, so it cannot be summarised.');
    }
    final en = manifest.getByLanguage('en');
    final info = en.isNotEmpty ? en.first : manifest.tracks.first;
    final track = await yt.videos.closedCaptions.get(info);
    final text = track.captions.map((c) => c.text.trim()).where((t) => t.isNotEmpty).join(' ');
    if (text.isEmpty) throw Exception('Captions were empty for this video.');
    return text;
  } finally {
    yt.close();
  }
}
