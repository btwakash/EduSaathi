# EduSaathi (Flutter)

## Setup
```
flutter create --org com.edusaathi --project-name edusaathi .   # generates android/ ios/ (keeps lib/ and pubspec.yaml)
flutter pub get
dart run flutter_launcher_icons
flutter run
```
Android: in `android/app/src/main/AndroidManifest.xml` add inside `<manifest>`:
```
<uses-permission android:name="android.permission.INTERNET"/>
<queries><intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent></queries>
```
Release APK: `flutter build apk --release`

## AI
No API key is bundled. Either build with `--dart-define=AI_PROXY_URL=https://your-proxy`
or enter your own key in Me → AI engine.
